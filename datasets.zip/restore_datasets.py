"""Restore the original CSV files using only the Python standard library."""

import argparse
import hashlib
import json
from pathlib import Path
import struct


def write_verified(target, data, expected_hash):
    if hashlib.sha256(data).hexdigest() != expected_hash:
        raise ValueError(f"Checksum mismatch: {target}")
    if target.is_file():
        if hashlib.sha256(target.read_bytes()).hexdigest() != expected_hash:
            raise FileExistsError(f"A different file already exists: {target}")
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    staging = target.with_name(target.name + ".part")
    staging.write_bytes(data)
    staging.replace(target)


def restore(package, output):
    manifest_data = (package / "split_manifest.json").read_bytes()
    manifest = json.loads(manifest_data)
    count = 0
    for dataset, protocols in manifest["folds"].items():
        catalog = json.loads((package / "catalog" / f"{dataset}.json").read_bytes())
        tokens = [token.encode("latin-1") for token in catalog["tokens"]]
        rows = [b",".join(tokens[index] for index in row) for row in catalog["rows"]]
        for protocol, folds in protocols.items():
            for fold, metadata in folds.items():
                for role, expected in metadata["csv_sha256"].items():
                    relative = Path(dataset, protocol, fold, role)
                    refs = (package / "splits" / relative.with_suffix(".bin")).read_bytes()
                    restored = b"".join(rows[index] for (index,) in struct.iter_unpack("<I", refs))
                    target = output / "data" / relative.with_suffix(".csv")
                    write_verified(target, restored, expected)
                    count += 1
        print(f"Restored and verified {dataset}", flush=True)
    write_verified(output / "split_manifest.json", manifest_data, hashlib.sha256(manifest_data).hexdigest())
    print(f"{count} CSV files restored and SHA-256 verified in {output.resolve()}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    package = Path(__file__).resolve().parent
    parser.add_argument("--output", type=Path, default=package, help="Destination project directory")
    args = parser.parse_args()
    restore(package, args.output)


if __name__ == "__main__":
    main()
